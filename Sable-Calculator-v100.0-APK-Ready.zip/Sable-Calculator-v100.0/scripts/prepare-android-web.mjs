import { cp, mkdir, rm, access, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'www');
const required = [
  'index.html','manifest.webmanifest','service-worker.js','assets/css/app.css',
  'assets/js/app.js','assets/js/sable-calculators.js','assets/js/localization.js','assets/js/currency-localized-names.js',
  'assets/js/theme-bootstrap.js','assets/brand/sable-icon.png',
  'assets/brand/sable-192.png','assets/brand/sable-512.png',
  'assets/brand/sable-mark.svg','assets/brand/sable-wordmark.svg'
];
for (const item of required) {
  try {
    await access(path.join(root, item));
    const content = await readFile(path.join(root, item));
    if (!content.length) throw new Error(`Required app asset is empty: ${item}`);
  } catch (error) {
    throw new Error(`Required app asset is missing or unreadable: ${item}`);
  }
}
const html = await readFile(path.join(root, 'index.html'), 'utf8');
const pkg = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
if (pkg.version !== '2.00.0-v100.0' || !html.includes(pkg.version)) {
  throw new Error(`Release identity mismatch: expected 2.00.0-v100.0, got ${pkg.version}`);
}
if (!html.includes('id="premium-tools-grid"') || !html.includes('data-tools-group="Convert"')) {
  throw new Error('New categorized Tools directory is missing from index.html');
}
await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const item of ['index.html','manifest.webmanifest','service-worker.js','assets']) {
  await cp(path.join(root, item), path.join(out, item), { recursive: true });
}
await access(path.join(out, 'assets/css/app.css'));
console.log(`Sable v100.0 Android web bundle prepared: ${required.length} assets verified; one canonical stylesheet copied.`);
