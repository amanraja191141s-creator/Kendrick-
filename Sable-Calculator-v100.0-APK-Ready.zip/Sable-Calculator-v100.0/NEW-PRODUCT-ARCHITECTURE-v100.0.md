# Sable v100.0 — independent product architecture

## Product idea
Sable is a calculation studio: a fast daily calculation desk plus a searchable library of task-specific calculators. It is not a visual clone of any single competitor. The design language and information architecture are original.

## Information architecture
- **Desk:** standard calculator with expression editing and live result preview.
- **Explore:** 23 tools in intent-based groups. Search matches the tool name and task. Saved tools are accessed here.
- **Activity:** reusable calculation history, with copy/edit/name/protect/delete actions.
- **Profile:** appearance, calculator behavior, input feedback, privacy and data preferences.

## Tool inventory
- Convert: Currency, Unit, Fuel Efficiency.
- Finance: Discount, Sales Tax, Loan, Savings, Tip, Unit Price, Bill Split, Compound Growth, Markup & Margin.
- Math: Percentage, Grade Average, Hexadecimal, Scientific, Ratio Split, Quick Statistics.
- Daily: Body Metrics, Date, Fuel Cost, World Time, Time Span.

## New calculation modules
`assets/js/sable-calculators.js` provides pure, testable functions for:
- Bill Split: subtotal + tip + tax, divided by a bounded whole-person count.
- Compound Growth: annual, quarterly, monthly or daily compounding; rejects unsupported frequency and non-finite output.
- Markup & Margin: profit, markup over cost and margin over selling price; zero-cost case is explicit.
- Ratio Split: weighted distribution; zero-sum ratios rejected.
- Quick Statistics: mean, median, range, population standard deviation; accepts comma/space/semicolon delimiters and caps input at 10,000 values.
- Time Span: elapsed minutes and readable day/hour/minute duration; invalid and reversed timestamps rejected.

## Theme system
- Modes: Light, Dark, Follow device.
- Accent palettes: Sable Ember, Quiet Sage, Harbor Slate, Soft Plum, Warm Marigold and Deep Teal.
- OLED True Black remains a separate optional surface mode.
- v3 preference migration resets the former forced-blue theme to Sable Ember / Light while preserving unrelated settings.

## Visual design system
- Light: warm paper `#f4f1e9`, graphite ink `#20231f`, persimmon `#e45b3d`.
- Dark: deep mineral green-black, softened graphite surfaces and readable warm text.
- Keypad and forms use shared spacing, shape, focus, type and state tokens.
- Narrow-width, short-height, safe-area and reduced-motion rules are included.

## Compatibility strategy
The old blue/navy design tokens, old branding, visible hamburger drawer and separate Saved bottom destination are removed from the new shell. The existing 17 calculation/provider engines remain as a compatibility core so working currency refresh, scientific, history and finance calculations are not silently discarded. The six new tools use a separate, testable module.

## Build
`npm test` runs the regression suite. `npm run build:web` creates the deterministic Capacitor `www` directory. GitHub Actions installs dependencies, runs tests, builds the web bundle, adds Android if absent, applies native Sable branding and uploads a debug APK artifact.
